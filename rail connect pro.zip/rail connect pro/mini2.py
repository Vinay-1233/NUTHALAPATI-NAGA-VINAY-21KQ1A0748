Python 3.12.2 (tags/v3.12.2:6abddd9, Feb  6 2024, 21:26:36) [MSC v.1937 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
============= RESTART: D:\movies\Books\internship\1\miniproject.py =============

Welcome to the Railway Ticket Reservation System!

Available Destinations:
Banglore
Chennai
Hyderabad

Please enter your destination (or type 'exit' to quit): Hyderabad

Available trains for Hyderabad (sorted by price):
Train1: Price = 175, Time = 2h 30m, Available Seats = 100
Train3: Price = 275, Time = 2h 15m, Available Seats = 120

Please enter the train you want to book (e.g., Train1): Train1
Enter the number of seats you want to book on Train1: 6

Booking Successful!
Train: Train1
Destination: Hyderabad
Price per ticket: 175
Total Price: 1050
Time: 2h 30m
Seats booked: 6
Remaining Seats: 94

